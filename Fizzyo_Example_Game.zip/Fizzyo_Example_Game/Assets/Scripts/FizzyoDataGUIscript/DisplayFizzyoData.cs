﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using Fizzyo;

public class DisplayFizzyoData : MonoBehaviour {

	float pressure = 0;
	int buttonPressCount = 0;
	int breathCount = 0;
	int breathQuality = 0;
	float breathLength = 0;

	void Start () {
	}

	void Update () {
		pressure = FizzyoFramework.Instance.Device.Pressure ();
		breathCount = FizzyoFramework.Instance.Recogniser.BreathCount;
        breathQuality = PlayerController.breathQuality;
        breathLength = PlayerController.breathLength;

		if (FizzyoFramework.Instance.Device.ButtonDown ()) {
			buttonPressCount += 1;
		}
	}
    //for displaying values on screen
    void OnGUI() {
		if (Input.GetKey (KeyCode.Space) != true) {
			GUIStyle mystyle = new GUIStyle ();
			mystyle.fontSize = 40;

			GUI.Box (new Rect (0, 0, 1000, 200), "<b>BREATH COUNT : " + breathCount + "\nBREATH LENGTH : " + breathLength +
				"\nBUTTON PRESSED : " + buttonPressCount + "\nBREATH QUALITY : " + breathQuality + "\nPRESSURE : " + pressure + "\nJUMP POWER : " + PlayerController.jumpPower + "\nHIGH SCORE : " + ScoreController.highScore + "\nCURRENT SCORE : " + (int)ScoreController.currentScore + "</b>", mystyle);
		}
	}
}
