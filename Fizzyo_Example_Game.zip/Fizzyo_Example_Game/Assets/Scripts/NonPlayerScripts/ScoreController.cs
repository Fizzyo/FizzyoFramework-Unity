﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Fizzyo;

public class ScoreController : MonoBehaviour {

    public static int highScore;
	public static float currentScore = 0;
	float originalPos = 0;
    float highestPoint = 0;
    public static GameObject toFollow;
    private bool startMeasure = false; //This is true once the Player first reaches the platform

	void Start () {
        toFollow = GameObject.Find("Player");
	}
	
	void LateUpdate () {
       //Player is on the platform, the game starts
        if (PlayerController.IsPlayerOnPlatform == true && startMeasure == false) {
            originalPos = toFollow.transform.position.y;
            startMeasure = true;
        }
        //Measure the position y of the Player and record as score
        if (PlayerController.IsPlayerOnPlatform == false && startMeasure == true) {
            currentScore = toFollow.transform.position.y - originalPos;

            if (currentScore > highScore) {
				highScore = (int)currentScore;
            }
        }	
	}
    //send highScore at the end
	void OnApplicationQuit(){
		FizzyoFramework.Instance.Analytics.Score = highScore;
		FizzyoFramework.Instance.Achievements.PostScore (highScore);
	}
}
