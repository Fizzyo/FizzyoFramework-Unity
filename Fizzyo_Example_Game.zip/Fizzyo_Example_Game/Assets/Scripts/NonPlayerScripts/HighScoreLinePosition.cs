﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Fizzyo;

public class HighScoreLinePosition : MonoBehaviour {
	Vector3 originalPosition;
	Vector3 linePosition;

	void Start () {
		originalPosition = transform.position;
	}

	void Update () {
		linePosition = new Vector3(0,(float)ScoreController.highScore + 3f, 0) + originalPosition;
		transform.position = linePosition;
	}
}
