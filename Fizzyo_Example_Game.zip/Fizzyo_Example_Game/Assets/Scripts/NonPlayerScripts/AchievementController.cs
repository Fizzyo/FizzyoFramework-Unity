﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Fizzyo;

public class AchievementController : MonoBehaviour
{

    public AchievementData[] allAchievements;
    public AchievementData[] unlockedAchievements;
    public GameObject AchievementEffect;

	bool isEffect = false;
	bool isUnlockable = true;
	public string achievementId = "9447e646-de00-4bf1-af33-5f1202d0f3b8";
	public int scoreToAchieve;

    void Start()
    {
        FizzyoFramework.Instance.Achievements.LoadAchievements();

        allAchievements = FizzyoFramework.Instance.Achievements.allAchievements;
        unlockedAchievements = FizzyoFramework.Instance.Achievements.unlockedAchievements;

		//search if already unlocked
		for (int i = 0; i < unlockedAchievements.Length; i++) {
			if (unlockedAchievements [i].id == achievementId) {
				isUnlockable = false;
				Debug.Log ("Achievement already unlocked!");
			}
		}
	}

    void Update()
	{
			//if condition matched, unlock achievement & trigger gui pop up
		if (ScoreController.currentScore > scoreToAchieve && isUnlockable == true) {
			FizzyoFramework.Instance.Achievements.UnlockAchievement (achievementId);
			FizzyoFramework.Instance.Achievements.LoadAchievements ();
			isEffect = true;
			isUnlockable = false;
			Instantiate (AchievementEffect);
		}
	}

    void OnGUI()
    {
        GUIStyle mystyle = new GUIStyle();
        mystyle.fontSize = 20;

        GUIStyle mystyle2 = new GUIStyle();
        mystyle2.fontSize = 60;
        mystyle2.normal.textColor = Color.yellow;
        
        if (Input.GetKey(KeyCode.Space))
        {
            //gui displays list of achievements
            for (int i = 0; i < allAchievements.Length; i++)
            {
                GUI.Box(new Rect(0, i * 100, 500, 100), "achID:\n" + allAchievements[i].id, mystyle);
            }
            for (int i = 0; i < unlockedAchievements.Length; i++)
            {
                GUI.Box(new Rect(0, 300 + i * 100, 500, 100), "unlockedachID:\n" + unlockedAchievements[i].id, mystyle);
            }

            GUI.Box(new Rect(0, 700, 500, 500), "userID: " + FizzyoFramework.Instance.User.UserID, mystyle);
        }
        //gui pop up when achievement is unlocked
		if (isEffect == true) {
			GUI.Box(new Rect(100, 600, 100, 100), "UNLOCKED ACHIEVEMENT: \nGet Score " + scoreToAchieve , mystyle2);
			StartCoroutine(WaitSeconds(2.0f));
		}
    }
    //wait for sometime before gui turns off
    IEnumerator WaitSeconds(float i)
    {
		yield return new WaitForSeconds(i);	
		isEffect = false;	
    }
}
