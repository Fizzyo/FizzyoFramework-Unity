﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectFollow : MonoBehaviour {

    private Vector3 originalPos; //for position of camera
    public GameObject toFollow; //game object to follow

	void Start () { 
        //offset position of gameObject
        originalPos = transform.position;
	}

	void LateUpdate () {
        transform.position = toFollow.transform.position + originalPos; //follow gameobject 
	}
}
