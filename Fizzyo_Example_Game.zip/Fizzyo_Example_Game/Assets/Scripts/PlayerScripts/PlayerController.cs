﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Fizzyo;

public class PlayerController: MonoBehaviour {

    //for controlling the player gameobject
    //gameobject build up jumpower with device breath blow
    //gameobject releases energy and jumps with device button

    private Rigidbody rb;
	public static float jumpPower, breathLength;
    public static bool IsPlayerOnPlatform = false, IsAbleToJump = false;
    public static int breathCount, breathQuality;
    private float pressure;

    void Start () {
        FizzyoFramework.Instance.Recogniser.BreathStarted += OnBreathStarted;
        FizzyoFramework.Instance.Recogniser.BreathComplete += OnBreathEnded;

        rb = this.gameObject.GetComponent<Rigidbody>();
	}

    void Update() {
        JumpController();
    }

    void JumpController()
    {

        pressure = FizzyoFramework.Instance.Device.Pressure();

        if (IsAbleToJump == true && jumpPower <= 1000) {
            jumpPower = jumpPower + pressure;
        }

        //only jump on the ground / not in the air
        //"jump" by adding force in the y direction
        //gameobject is set to dynamic, so falls with gravity
        if (IsPlayerOnPlatform == true){
            if (FizzyoFramework.Instance.Device.ButtonDown()) {
                rb.AddForce(0, 10 * jumpPower, 0);
                IsAbleToJump = false;
            }
        }
        // don't generate jump power if it shouldn't
        else if (IsAbleToJump == false || IsPlayerOnPlatform == false){ jumpPower = 0; }
    }
    
    // jumpPower resets every breath
    void OnBreathStarted(object sender) { 
        IsAbleToJump = true;
        jumpPower = 0;
    }
 
	void OnBreathEnded(object sender, ExhalationCompleteEventArgs e) {
        breathCount = e.BreathCount;
        breathLength = e.Breathlength;
        breathQuality = e.BreathQuality;
    }

    private void OnCollisionEnter(Collision collision) {
        IsPlayerOnPlatform = true;
    }

    private void OnCollisionExit(Collision collision) {
        IsPlayerOnPlatform = false;
    }
}
